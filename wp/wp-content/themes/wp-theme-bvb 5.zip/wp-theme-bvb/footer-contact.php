
    <!-- Footer -->
    <div id="footer">
        <div class="copyright">
            &copy; Vestea Bună București
        </div>
    </div>

    <!-- Scripts -->
    <script src="<?php echo get_template_directory_uri() . '/assets/js/jquery.min.js'; ?>"></script>
    <script src="<?php echo get_template_directory_uri() . '/assets/js/skel.min.js'; ?>"></script>
    <script src="<?php echo get_template_directory_uri() . '/assets/js/jquery.dropotron.min.js'; ?>"></script>
    <script src="<?php echo get_template_directory_uri() . '/assets/js/jquery.onvisible.min.js'; ?>"></script>
    <script src="<?php echo get_template_directory_uri() . '/assets/js/jquery.dropotron.min.js'; ?>"></script>
    <script src="<?php echo get_template_directory_uri() . '/assets/js/jquery.poptrox.min.js'; ?>"></script>
    <script src="<?php echo get_template_directory_uri() . '/assets/js/util.js'; ?>"></script>
    <script src="<?php echo get_template_directory_uri() . '/assets/js/main.js'; ?>"></script>
    <!--[if lte IE 8]><script src="<?php echo get_template_directory_uri() . '/assets/js/ie/respond.min.js'; ?>"></script><![endif]-->

</body>

</html>