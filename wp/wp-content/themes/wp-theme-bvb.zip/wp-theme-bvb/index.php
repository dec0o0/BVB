<?php get_header(); ?>
 
    <!-- Banner -->
    <section id="banner">
        <h2>Isus Hristos</h2>
        <p>Ne leagă, ne adună, datorită lui zâmbim.</p>
        <ul class="actions">
            <li class="button-wrap"><button href="#" class="button special trigger" data-dialog="somedialog">Evenimente</button></li>
        </ul>

    </section>

<?php get_sidebar(); ?>
<?php get_footer(); ?>